package com.example.maventraining;

/**
 * This is a very important class of our project
 */
public class HelloWorld {

    /**
     * This is the hello method that will do crazy stuff
     * @return
     */
    public String hello() {

        return "Hello, World!";
    }
}
