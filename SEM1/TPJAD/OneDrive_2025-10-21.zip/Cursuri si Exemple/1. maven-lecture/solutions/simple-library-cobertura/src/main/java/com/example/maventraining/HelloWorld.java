package com.example.maventraining;

public class HelloWorld {
    public String hello() {
        return "hello!";
    }
}
