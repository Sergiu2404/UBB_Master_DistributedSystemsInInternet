package com.example.maventraining.hello.util;

public class HelloWorld {
    public String hello(String name) {
        return "Hello, " + name + "!";
    }
}
