package com.example.maventraining.hello.util;

public class AnotherHelloWorld {
    public String hello(String name) {
        return "Hello, " + name + "!";
    }
    public String helloAgain () {
        return "Hello again!";
    }
}
