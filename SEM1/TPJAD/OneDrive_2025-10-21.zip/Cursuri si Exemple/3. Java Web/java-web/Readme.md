1. Servlet clasic - hello-web
2. Servlet annotations - servlet-web
3. Servlet filter - servlet-filter-web
4. Servlet embedded