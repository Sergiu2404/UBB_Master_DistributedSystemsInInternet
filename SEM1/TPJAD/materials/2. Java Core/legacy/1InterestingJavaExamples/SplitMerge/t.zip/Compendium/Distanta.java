public class Distanta {
   public static void main(String a[]) throws Exception {
   // Determina distanta intre punctele de coordonate (a[0],a[1]), (a[2],a[3])
      double x1 = Double.parseDouble(a[0]);
      double y1 = Double.parseDouble(a[1]);
      double x2 = Double.parseDouble(a[2]);
      double y2 = Double.parseDouble(a[3]);
      System.out.println("Distanta este: "+	// Afiseaza distanta
      Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1)));
   }//Distanta.main
}//Distanta

