public class Echo {
   public static void main(String a[]){
      System.out.println("Urmeaza cele "+a.length+" argumente:");
      for(int i=0;i<a.length;i++)
         System.out.println(a[i]);
   }//Echo.main
}//Echo

