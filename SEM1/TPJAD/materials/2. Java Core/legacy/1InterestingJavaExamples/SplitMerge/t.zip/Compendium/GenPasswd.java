import java.io.*;
import java.util.*;
public class GenPasswd {
   public static void main(String a[]) {
      String car = "abcdefghijklmnopqrstuvwxyz"+
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ"+
      "0123456789"; // Alfabetul
      StringBuffer lin = new StringBuffer("        "); // Spatiu pentru o parola
      Random r = new Random(); // Obiect numar aleator
      for (int n=0; n<2000; n++) {
         for(int i=0; i<8; i++)
            lin.setCharAt(i,
            car.charAt(
            Math.abs(r.nextInt())%car.length())); // Genereaza un caracter
         System.out.println(lin); // Tipareste o parola
      }// for: cele 2000 parole generate
   }// GenPasswd.main
}// GenPasswd

