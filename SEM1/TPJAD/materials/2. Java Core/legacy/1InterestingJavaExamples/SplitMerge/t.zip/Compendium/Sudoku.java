import java.io.*;
import java.util.*;
public class Sudoku extends Thread {
  public static final int n = 9, sqrtn = 3;
  int table[][];
  public static void main(String a[]) throws Exception {
    int table[][];
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    table = new int[n][n];
    for(int i=0;i<n;i++) {
      String s = in.readLine();
      for (int j=0; j<n; j++) {
        table[i][j] = s.charAt(j)-'0';
      }
    }
    new Sudoku(table, "Start");
  }
  public Sudoku(int table[][], String parent) {
    this.table = table;
    System.out.println(this.getName()+" <-- "+parent);
    this.start();
  }
  public void run() {
    MathSet row[], col[], cell[][], full;
    row = new MathSet[n];
    col = new MathSet[n];
    cell = new MathSet[sqrtn][sqrtn];
    full = new MathSet();
    MathSet minim=null, temp=null;
    int iMin=-1, jMin=-1, i=-1, j=-1;
    Integer t=null;
    for (i=0; i<n; row[i]=new MathSet(), col[i]=new MathSet(), full.add(new Integer(i+1)), i++);
    for (i=0; i<sqrtn; i++)
      for (j=0; j<sqrtn; cell[i][j]=new MathSet(), j++);
    for (i=0; i<n; i++) {
      for (j=0; j<n; j++) {
        if (table[i][j] < 0 || table[i][j] > n)
          table[i][j] = 0;
        t = table[i][j];
        if (t == 0)
          continue;
        if (row[i].contains(t) || col[j].contains(t) || cell[i/sqrtn][j/sqrtn].contains(t)) {
          System.out.println(this.getName()+" "+i+" "+j+" "+t+" valoare imposibila");
          return;
        }
        row[i].add(t);
        col[j].add(t);
        cell[i/sqrtn][j/sqrtn].add(t);
      }
    }
    for (i=0; i<n; i++) {
      row[i] = full.difference(row[i]);
      col[i] = full.difference(col[i]);
    }
    for (i=0; i<sqrtn; i++) {
      for (j=0; j<sqrtn; j++) {
        cell[i][j] = full.difference(cell[i][j]);
      }
    }
    FIXUNIQUES: for ( ; ; ) {
      iMin = -1;
      for (i=0; i<n; i++) {
        for (j=0; j<n; j++) {
          t = table[i][j];
          if (t > 0)
            continue;
          temp = row[i].intersection(col[j].intersection(cell[i/sqrtn][j/sqrtn]));
          if (temp.size() == 0)
            return;
          if (temp.size() > 1) {
            if (iMin == -1) {
              iMin = i;
              jMin = j;
              minim = temp;
            } else {
              if (minim.size() > temp.size()) {
                iMin = i;
                jMin = j;
                minim = temp;
              }
            }
            continue;
          }
          Iterator tt=temp.iterator();
          t = (Integer)tt.next();
          table[i][j] = t;
          row[i].remove(t);
          col[j].remove(t);
          cell[i/sqrtn][j/sqrtn].remove(t);
          continue FIXUNIQUES;
        }
      }
      break;
    }
    if (iMin == -1) {
      String s = this.getName()+" Solutie:";
      for (i=0; i<n; i++) {
        s += "\n\t";
        for (j=0; j<n; s+=table[i][j], j++);
      }
      System.out.println(s);
      return;
    }
    System.out.println(this.getName()+": In ("+iMin+","+jMin+") se va alege din "+minim);
    for (Iterator tt=minim.iterator(); tt.hasNext(); ) {
      int[][] newTable = new int[n][n];
      for (int x=0; x<n; x++)
        for(int y=0; y<n; newTable[x][y] = table[x][y], y++);
      newTable[iMin][jMin] = (Integer)tt.next();
      new Sudoku(newTable, this.getName());
    }
  }
}
