import java.util.*;
class RecipientCuvinte {
    private Vector b = new Vector();
    private String continut;
    private int RECIPIENT;
    
    public RecipientCuvinte(int recipient) {
        RECIPIENT = recipient;
    }//RecipientCuvinte.RecipientCuvinte
    public synchronized String get() { // Extrage urmatorul cuvant din recipient, daca are ce extrage
        while (b.size()==0) {
            try { wait();
            }//try
            catch (Exception e) {
                e.printStackTrace();
            }//catch
        }//while
        continut = (String)b.elementAt(0); // Extrage cuvantul
        b.remove(0); // Sterge-l
        notify();
        return continut;
    }//RecipientCuvinte.get
    public synchronized void put(String continut) { // Depune inca un cuvant in recipient, daca are loc
        while (b.size()>=RECIPIENT) {
            try { wait();
            }//try
            catch (Exception e) {
                e.printStackTrace();
            }//catch
        }//while
        b.add(continut);
        notify();
    }//RecipientCuvinte.put
}//RecipientCuvinte

