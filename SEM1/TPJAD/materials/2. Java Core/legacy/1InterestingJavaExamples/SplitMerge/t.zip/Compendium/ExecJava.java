import java.io.*;

   public class ExecJava {

      static String com="R.bat";
      static int SMAX=1000;
              
      public static void main(String argv[]) {
         try {	
            Process p;
            p=Runtime.getRuntime().exec(com);
            p.waitFor();

            //obtine codul de retur al aplicatiei externe
            int exval=p.exitValue();
            System.out.println(exval);

            //obtine datele de iesire
            InputStream in=p.getInputStream();
            byte blin[]=new byte[SMAX];
            int noct=in.read(blin,0,SMAX);
            String s=new String(blin,0,noct);
            System.out.println(s);
         }
            catch(IOException e1) {
               System.out.println(e1);
            }
            catch(InterruptedException e2){
               System.out.println(e2);}
      }//ExecJava.main
   }//ExecJava

