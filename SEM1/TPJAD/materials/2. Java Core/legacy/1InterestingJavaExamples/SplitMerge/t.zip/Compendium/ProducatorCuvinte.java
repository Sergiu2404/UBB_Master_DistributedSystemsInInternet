import java.util.*;
import java.io.*;
class ProducatorCuvinte extends Thread {
    private RecipientCuvinte r;
    private BufferedReader in;
    ProducatorCuvinte(RecipientCuvinte r, BufferedReader in) {
        this.r = r;
        this.in = in;
    }//ProducatorCuvinte.ProducatorCuvinte
    public void run() {
        String s = "";
        StringTokenizer st;
        r.put("\t");
        for (;;) {
            try {
                s = in.readLine();
            }//try
            catch (Exception e) {
                e.printStackTrace();
            }//catch
            if (s == null)
                break;	//Sfarsit fisier intrare
            if (s.equals("")) {
                r.put("\t");	//Depune marcaj de paragraf
                continue;
            }//if
            if (s.charAt(0) == '\t')
                r.put("\t");	//Depune marcaj de paragraf
            st = new StringTokenizer(s.trim());
            for ( ; st.hasMoreTokens(); )
                r.put(st.nextToken());	//Depune cuvant
        }//for
        r.put("\n");	//Depune sfarsit de fisier
    }//ProducatorCuvinte.run
}//ProducatorCuvinte

