public class Salut{
   public static void main(String a[]) {
      System.out.println("Salut");
   }//Salut.main
}//Salut

