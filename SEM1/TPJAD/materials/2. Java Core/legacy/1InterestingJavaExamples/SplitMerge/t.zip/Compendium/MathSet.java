/** MathSet.java **/
import java.util.*;
public class MathSet extends HashSet {
  public final boolean isSuperset(MathSet s) {
    return this.containsAll(s);
  }
  public final boolean isSubset(MathSet s) {
    return s.containsAll(this);
  }
  public final boolean isDisjoint(MathSet s) {
    MathSet intersection = this.intersection(s);
    return intersection.isEmpty();
  }
  public final MathSet union(MathSet s) {
    MathSet union = (MathSet) this.clone();
    union.addAll(s);
    return union;
  }
  public final MathSet intersection(MathSet s) {
    MathSet intersection = (MathSet) this.clone();
    intersection.retainAll(s);
    return intersection;
  }
  public final MathSet difference(MathSet s) {
    MathSet difference = (MathSet) this.clone();
    difference.removeAll(s);
    return difference;
  }
  public final String toString() {
    StringBuffer buffer = new StringBuffer();
    String string;
    buffer.append("{");
    Iterator thisIt = this.iterator();
    while (thisIt.hasNext()) {
      buffer.append(thisIt.next());
      if (thisIt.hasNext()) buffer.append(",");
    }
    buffer.append("}");
    string = buffer.toString();
    return string;
  }
}
