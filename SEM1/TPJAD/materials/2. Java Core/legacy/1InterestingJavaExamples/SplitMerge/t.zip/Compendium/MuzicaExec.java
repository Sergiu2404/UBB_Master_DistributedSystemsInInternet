import java.io.*;
public class MuzicaExec {
//      static String com="c:/Program Files/Windows Media Player/mplayer2.exe E:/filme/Troy [2004-7'0] Action-Drama-War/Troy_part1.avi ";
  static String com="c:/Program Files/Windows Media Player/mplayer2.exe ./maneaua_informaticianului.mp3  ";
//        static String com="c:/Program Files/Windows Media Player/mplayer2.exe c:/WINDOWS/clock.avi ";
  public static void main(String argv[]) throws Exception {
    Process p;
    p=Runtime.getRuntime().exec(com);
    p.waitFor();
  }
}
