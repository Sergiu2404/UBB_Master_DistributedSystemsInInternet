import java.io.*;
class AliniereCuvinte {
    final public int LUNGIME = 60, RECIPIENT = 100;
    RecipientCuvinte r;
    ProducatorCuvinte p;
    ConsumatorCuvinte c;
    public static void main(String[] a) {
        AliniereCuvinte ac = new AliniereCuvinte();
        ac.r = new RecipientCuvinte(ac.RECIPIENT);
        ac.p = new ProducatorCuvinte(ac.r,
        new BufferedReader(
        new InputStreamReader(System.in)));
        ac.c = new ConsumatorCuvinte(ac.r, System.out, ac.LUNGIME);
        ac.p.start();
        ac.c.start();
    }//AliniereCuvinte.main
}//AliniereCuvinte

