import java.io.*;
import java.util.*;
public class Linii {
   public static void main(String a[]) {
      BufferedReader in = new BufferedReader(
      new InputStreamReader(System.in));
      String s, d; // Stringuri de serviciu
      Vector ts = new Vector(); // Tabloul de stringuri
      int n;
      for(n=0; ; ) { // Citeste linie cu linie si adauga la ts
         s=null;
         try {
            s = in.readLine();
         }//try
         catch (IOException e) {
            e.printStackTrace();
         }// catch
         if (s==null)
            break; // S-a tastat sfarsitul intrarii
         ts.add(s);
         n++;
      }//for
      for(int i=0; i<n-1; i++){ // Ordoneaza tabloul
         for(int j=i+1; j<n; j++) {
            d=(String)ts.elementAt(j);
            s=(String)ts.elementAt(i);
            if (s.compareTo(d) > 0) {
               ts.set(i, d);
               ts.set(j, s);
            }//if
         }//for j
      }//for i
      System.out.println("\nLiniile ordonate lexicografic:\n");
      for (int i=0; i<n;i++){
         s=(String)ts.elementAt(i);
         System.out.println(s); // Afiseaza liniile
      }//for
   }//Linii.main
}//Linii

