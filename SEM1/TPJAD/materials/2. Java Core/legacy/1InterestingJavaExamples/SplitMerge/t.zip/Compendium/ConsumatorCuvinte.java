import java.io.*;
import java.util.*;
class ConsumatorCuvinte extends Thread {
    private RecipientCuvinte r;
    private PrintStream out;
    private int LUNGIME;
    ConsumatorCuvinte(RecipientCuvinte r, PrintStream out, int lungime) {
        this.r = r;
        this.out = out;
        LUNGIME = lungime;
    }//ConsumatorCuvinte.ConsumatorCuvinte
    private String distantare(String s) {
        int i, nrSeparatori, nrSeparatoriMaiLungi=0, pas=0, start, x;
        String separator;
        StringTokenizer st;
        for (i=0, nrSeparatori=0; i<s.length(); i++)
            if (s.charAt(i) == ' ')
                nrSeparatori++;
        if (nrSeparatori == 0)
            return s;
        nrSeparatoriMaiLungi = (LUNGIME - s.length()) % nrSeparatori;
        if (nrSeparatoriMaiLungi != 0)
            pas = nrSeparatori / nrSeparatoriMaiLungi;
        start = pas / 2;
        x = (pas+1)*(nrSeparatoriMaiLungi-1)+1;
        if (x <= nrSeparatori) {
            pas++;
            start = (nrSeparatori - x) /2;
        }//if
        for (i=0, separator=" "; i<(LUNGIME-s.length())/nrSeparatori; i++, separator+= " ");
        st = new StringTokenizer(s);
        for (i=0; st.hasMoreTokens(); i++)
            if (i==0)
                s = st.nextToken();
            else if (nrSeparatoriMaiLungi == 0)
                s += separator+st.nextToken();
            else if ((((i-1)%pas)!=start))
                s += separator+st.nextToken();
            else {
                s += " "+separator+st.nextToken();
                nrSeparatoriMaiLungi--;
            }//if
        return s;
    }//ConsumatorCuvinte.distantare
    public void run() {
        String linie = "", cuvant;
        for (; ; ) {
            cuvant = r.get();
            if (cuvant.equals("\n"))
                break;	//Sfarsitul intrarii de cuvinte
            if (cuvant.equals("\t")) {
                if (linie.equals(""))
                    continue;
                out.println(linie);
                out.println();	//Incheie vechiul paragraf
                linie = "";
                continue;
            }//if
            if (linie.length()+1+cuvant.length() >= LUNGIME) {
                out.println(distantare(linie));	//Scrie o linie din paragraf
                linie = "";
            }//if
            if (linie.equals(""))
                linie = cuvant;
            else
                linie += " "+cuvant;
        }//for
        out.println(linie);
    }//ConsumatorCuvinte.run
}//ConsumatorCuvinte

