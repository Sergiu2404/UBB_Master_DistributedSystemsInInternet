import java.io.*;
import java.util.*;
public class GenExpr {
   public static void main(String a[]) {
      String var="abcde"; // Variabilele
      String neg=" -";    // Negare sau nu
      String s;
      int v, n, t, i, j, k;
      Random r  = new Random(); // Obiectul numar aleator
      for (i=0; i<20; i++) {
         v = 3 + Math.abs(r.nextInt())%3; // Numar de variabile
         t = 4 + Math.abs(r.nextInt())%8; // Numar de termeni conjunctivi
         for (s = "f(",k=0; k<v; k++) {
            s += var.substring(k,k+1);
            s += (k<v-1)?",":")  =  ";
         } // for: Partea stanga a definirii functiei
         for(j=0; j<t; j++) {
            for (k=0; k<v; k++) {
               n = Math.abs(r.nextInt())%2; // Alege negare sau nu
               s +=neg.substring(n,n+1)+var.substring(k,k+1); // Lipeste
                                              // variabila negata sau nu
            } // for: generat un termen conjunctiv
            if (j < t-1)
               s += "  V  "; // Pune operatorul SAU
         } // for: Expresia booleeana
         System.out.println(s); // Tipareste expresia generata
      }// for: cele 20 expresii
   }// GenExpr.main
}// GenExpr

