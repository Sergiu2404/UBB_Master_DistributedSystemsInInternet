import java.io.*;
public class MediiPonderate {
   public static void main(String a[]) throws Exception {
      int i;
      String s;
      BufferedReader in = new BufferedReader(
      new InputStreamReader(System.in));
      double[] p = new double [a.length];
      double[] n = new double [a.length];
      double medie, total;
      for (i=0, total=0; i<a.length; i++) {
         p[i] = Double.parseDouble(a[i]);
         total += p[i];
      }//for
      for (;; ) {
         for (i=0, medie=0; i<a.length;i++) {
            System.out.print("Nota "+(i+1)+": ");
            s = in.readLine();
            if (s == null)
               System.exit(0);
            medie += (p[i]*Double.parseDouble(s));
         }//for
         medie /= total;
         System.out.println("Media: "+medie);
      }//for
   }//MediiPonderate.main
}//MediiPonderate

