import java.applet.*;
import java.awt.*;
public class SalutAp extends Applet {
   public void paint(Graphics g) {
      g.drawString("Salut",10,50);
   }//SalutAp.paint
}//SalutAp

