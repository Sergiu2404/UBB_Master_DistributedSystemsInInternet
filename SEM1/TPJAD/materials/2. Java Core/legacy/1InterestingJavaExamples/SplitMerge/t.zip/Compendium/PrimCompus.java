import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class PrimCompus extends Applet {
   public static void main(String a[]) {
      PrimCompus oPrimCompus = new PrimCompus();
      Frame oFrame = new Frame("Fereastra standalone");
/*      WindowListener l=new WindowAdapter() {
         public void windowClosing(WindowEvent e) {
            System.exit(0);
         }
      };
      oFrame.addWindowListener(l);*/
      oFrame.setSize(250,350);
      oFrame.add("Center", oPrimCompus);
      oFrame.show();
      oPrimCompus.init();
   }//PrimCompus.main
   public void init() {
   }//PrimCompus.init
   public void paint(Graphics g) {
      g.drawString("Un sir in fereastra",50,60);
   }//PrimCompus.paint
}//PrimCompus

