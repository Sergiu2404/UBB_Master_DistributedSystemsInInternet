package com.sqlite;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements View.OnClickListener {
    private EditText numeSectii;
    private EditText descriere;
    private EditText numeAngajati;
    private EditText varstaAngajati;
    private EditText sectiaAngajati;
    private EditText caracterizareAngajati;
    Load load;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        numeSectii = (EditText) findViewById(R.id.numeSectii);
        descriere = (EditText) findViewById(R.id.descriere);
        numeAngajati = (EditText) findViewById(R.id.numeAngajati);
        varstaAngajati = (EditText) findViewById(R.id.varstaAngajati);
        sectiaAngajati = (EditText) findViewById(R.id.sectiaAngajati);
        caracterizareAngajati = (EditText) findViewById(R.id.caracterizareAngajati);

        Button afisare = (Button) findViewById(R.id.afisare);
        Button adauga = (Button) findViewById(R.id.adauga);
        afisare.setOnClickListener(this);
        adauga.setOnClickListener(this);
        load = Load.getInstance(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.adauga:
                adauga();
                break;
            case R.id.afisare:
                Intent intent = new Intent(this,ConsultActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void adauga() {
        if (isSectie())
            adaugaSectie();
        if (isAngajat())
            adaugaAngajati();
    }

    private boolean isSectie() {
        return !numeSectii.getText().toString().isEmpty() && !descriere.getText().toString().isEmpty();
    }

    private void adaugaSectie() {
        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(SectiiContract.COLUMN_NAME_NUME, numeSectii.getText().toString());
        values.put(SectiiContract.COLUMN_NAME_DESCRIERE, descriere.getText().toString());

        // Insert the new row, returning the primary key value of the new row
        long newRowId = load.getWritableDatabase().insert(SectiiContract.TABLE_NAME, null, values);
    }

    private boolean isAngajat() {
        return !numeAngajati.getText().toString().isEmpty() && !varstaAngajati.getText().toString().isEmpty()
                && !sectiaAngajati.getText().toString().isEmpty() && !caracterizareAngajati.getText().toString().isEmpty();
    }

    private void adaugaAngajati() {
        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(AngajatiContract.COLUMN_NAME_NUME, numeAngajati.getText().toString());
        values.put(AngajatiContract.COLUMN_NAME_SECTIA, sectiaAngajati.getText().toString());
        values.put(AngajatiContract.COLUMN_NAME_VARSTA, varstaAngajati.getText().toString());
        values.put(AngajatiContract.COLUMN_NAME_CARACTERIZARE, caracterizareAngajati.getText().toString());

        // Insert the new row, returning the primary key value of the new row
        long newRowId = load.getWritableDatabase().insert(AngajatiContract.TABLE_NAME, null, values);
    }

}
