package com.sqlite;

import android.provider.BaseColumns;

/**
 * Created by Tudor on 14-Nov-16.
 */

public final class SectiiContract implements BaseColumns {
    private SectiiContract() {
    }

    public static final String TABLE_NAME = "sectii";
    public static final String COLUMN_NAME_NUME = "nume";
    public static final String COLUMN_NAME_DESCRIERE = "descriere";

    static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    _ID + " INTEGER PRIMARY KEY," +
                    COLUMN_NAME_NUME + " TEXT UNIQUE," +
                    COLUMN_NAME_DESCRIERE + " TEXT" +
                    " )";

    static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;
}
