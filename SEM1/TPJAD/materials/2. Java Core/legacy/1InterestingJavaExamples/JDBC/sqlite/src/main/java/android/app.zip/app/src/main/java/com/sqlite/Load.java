package com.sqlite;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Tudor on 14-Nov-16.
 */

public class Load extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "dbexemplu.db";
    private static Load load;

    private Load(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public Load(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SectiiContract.SQL_CREATE_ENTRIES);
        sqLiteDatabase.execSQL(AngajatiContract.SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(SectiiContract.SQL_DELETE_ENTRIES);
        sqLiteDatabase.execSQL(AngajatiContract.SQL_DELETE_ENTRIES);
        onCreate(sqLiteDatabase);
    }
    public static Load getInstance(Context context){
        if (load==null)
            load = new Load(context);
        return load;
    }
}
