package com.sqlite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ConsultActivity extends Activity implements View.OnClickListener {
    Load load;
    private Button afiseazaAngajati;
    private EditText mainBatranDecat;
    private Button afiseazaSectii;
    private TextView dbData;
    private EditText sectia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consult);
        load = Load.getInstance(this);
        afiseazaAngajati = (Button) findViewById(R.id.afiseazaAngajati);
        afiseazaSectii = (Button) findViewById(R.id.afiseazaSectii);
        mainBatranDecat = (EditText) findViewById(R.id.maiBatranDecat);
        sectia = (EditText) findViewById(R.id.sectia);
        dbData = (TextView) findViewById(R.id.dbData);

        afiseazaSectii.setOnClickListener(this);
        afiseazaAngajati.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.afiseazaAngajati:
                afiseazaAngajati();
                break;
            case R.id.afiseazaSectii:
                afiseazaSectii();
                break;
        }
    }

    private void afiseazaAngajati() {
        if (mainBatranDecat.getText().toString().isEmpty() || sectia.getText().toString().isEmpty())
            afiseazaTotiAngajatii();
        else
            afiseazaAngajatiiDeLaSectiaXMaiBatraniDecatY();
    }

    private void afiseazaAngajatiiDeLaSectiaXMaiBatraniDecatY() {
        String maiBatran = mainBatranDecat.getText().toString();
        String sectiaStr = sectia.getText().toString();
        Cursor cursor = load.getReadableDatabase().query(AngajatiContract.TABLE_NAME, null/*all columns*/,
                AngajatiContract.COLUMN_NAME_SECTIA + " = ? AND " + AngajatiContract.COLUMN_NAME_VARSTA + " > ?"
                , new String[]{sectiaStr, maiBatran}, null, null, null);
        cursor.moveToFirst();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(AngajatiContract.COLUMN_NAME_NUME + "\t\t");
        stringBuilder.append(AngajatiContract.COLUMN_NAME_SECTIA + "\t\t");
        stringBuilder.append(AngajatiContract.COLUMN_NAME_VARSTA + "\t\t");
        stringBuilder.append(AngajatiContract.COLUMN_NAME_CARACTERIZARE + "\n");
        while (!cursor.isAfterLast()) {
            int nameIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_NUME);
            int caracterizareIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_CARACTERIZARE);
            int sectiaIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_SECTIA);
            int varstaIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_VARSTA);
            String nume = cursor.getString(nameIndex);
            String caracterizare = cursor.getString(caracterizareIndex);
            String sectia = cursor.getString(sectiaIndex);
            int varsta = cursor.getInt(varstaIndex);
            stringBuilder.append(nume);
            stringBuilder.append("\t\t\t");
            stringBuilder.append(sectia);
            stringBuilder.append("\t\t\t");
            stringBuilder.append(varsta);
            stringBuilder.append("\t\t\t\t\t");
            stringBuilder.append(caracterizare);
            stringBuilder.append("\n");

            cursor.moveToNext();
        }
        cursor.close();
        dbData.setText(stringBuilder.toString());
    }

    private void afiseazaTotiAngajatii() {
        Cursor cursor = load.getReadableDatabase().query(AngajatiContract.TABLE_NAME, null/*all columns*/,
                null, null, null, null, null);
        cursor.moveToFirst();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(AngajatiContract.COLUMN_NAME_NUME + "\t\t");
        stringBuilder.append(AngajatiContract.COLUMN_NAME_SECTIA + "\t\t");
        stringBuilder.append(AngajatiContract.COLUMN_NAME_VARSTA + "\t\t");
        stringBuilder.append(AngajatiContract.COLUMN_NAME_CARACTERIZARE + "\n");
        while (!cursor.isAfterLast()) {
            int nameIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_NUME);
            int caracterizareIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_CARACTERIZARE);
            int sectiaIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_SECTIA);
            int varstaIndex = cursor.getColumnIndex(AngajatiContract.COLUMN_NAME_VARSTA);
            String nume = cursor.getString(nameIndex);
            String caracterizare = cursor.getString(caracterizareIndex);
            String sectia = cursor.getString(sectiaIndex);
            int varsta = cursor.getInt(varstaIndex);
            stringBuilder.append(nume);
            stringBuilder.append("\t\t\t");
            stringBuilder.append(sectia);
            stringBuilder.append("\t\t\t");
            stringBuilder.append(varsta);
            stringBuilder.append("\t\t\t\t\t");
            stringBuilder.append(caracterizare);
            stringBuilder.append("\n");

            cursor.moveToNext();
        }
        cursor.close();
        dbData.setText(stringBuilder.toString());
    }

    private void afiseazaSectii() {
        Cursor cursor = load.getReadableDatabase().query(SectiiContract.TABLE_NAME, null/*all columns*/,
                null, null, null, null, null);
        cursor.moveToFirst();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(SectiiContract.COLUMN_NAME_NUME + "\t\t" + SectiiContract.COLUMN_NAME_DESCRIERE + "\n");
        while (!cursor.isAfterLast()) {
            int nameIndex = cursor.getColumnIndex(SectiiContract.COLUMN_NAME_NUME);
            int descriereIndex = cursor.getColumnIndex(SectiiContract.COLUMN_NAME_DESCRIERE);
            String nume = cursor.getString(nameIndex);
            String descriere = cursor.getString(descriereIndex);
            stringBuilder.append(nume);
            stringBuilder.append("\t\t\t\t\t");
            stringBuilder.append(descriere);
            stringBuilder.append("\n");
            cursor.moveToNext();
        }
        cursor.close();
        dbData.setText(stringBuilder.toString());
    }
}
