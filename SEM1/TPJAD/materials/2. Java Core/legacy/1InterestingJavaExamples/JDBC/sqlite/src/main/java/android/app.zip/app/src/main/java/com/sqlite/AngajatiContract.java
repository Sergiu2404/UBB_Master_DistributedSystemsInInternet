package com.sqlite;

import android.provider.BaseColumns;

/**
 * Created by Tudor on 14-Nov-16.
 */

public final class AngajatiContract implements BaseColumns {
    private AngajatiContract() {
    }

    public static final String TABLE_NAME = "angajati";
    public static final String COLUMN_NAME_NUME = "nume";
    public static final String COLUMN_NAME_VARSTA = "varsta";
    public static final String COLUMN_NAME_SECTIA = "sectia";
    public static final String COLUMN_NAME_CARACTERIZARE = "caracterizare";

    static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    _ID + " INTEGER PRIMARY KEY," +
                    COLUMN_NAME_NUME + " TEXT UNIQUE," +
                    COLUMN_NAME_VARSTA + " INTEGER," +
                    COLUMN_NAME_SECTIA + " INTEGER," +
                    COLUMN_NAME_CARACTERIZARE + " TEXT," +
                    " FOREIGN KEY (" + COLUMN_NAME_SECTIA + ") REFERENCES " +
                    SectiiContract.TABLE_NAME + "(" + SectiiContract.COLUMN_NAME_NUME + "));";

     static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;
}
